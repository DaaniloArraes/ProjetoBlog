<footer>
    <p>Hora de Codar &copy; 2024</p>
</footer>
</body>
</html>