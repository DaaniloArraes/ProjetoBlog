<?php 
    include_once("templates/header.php");
?>

    <div id="contato-container">
        <h1 id="contato-content">Danilo Arraes (11) 95237-7610</h1>
    </div>
<?php 
    include_once("templates/footer.php");
?>
